﻿

namespace WildFarm.Models.Contracts
{
  public  interface IFoodable
    {
        public abstract int FoodQuantity { get; }
    }
}
