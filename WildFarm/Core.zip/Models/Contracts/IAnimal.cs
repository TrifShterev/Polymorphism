﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models
{
   public interface IAnimal
    {
        public string Name { get;  }
        public double Weight { get;  }

    }
}
